#!/bin/sh
python mlp/main.py