#!/bin/sh
cd "$(dirname "$0")"
python mlp/main.py